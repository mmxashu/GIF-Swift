package com.remotedial

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.gson.Gson
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket

class SocketServerService : Service() {

    companion object {
        const val PORT = 8888
        const val CHANNEL_ID = "RemoteDialChannel"
        const val NOTIFICATION_ID = 1
        const val ACTION_LOG = "com.remotedial.LOG"
        const val EXTRA_LOG = "log_message"
        var isRunning = false
        var secretToken = "remotedial123"
    }

    private var serverSocket: ServerSocket? = null
    private val gson = Gson()
    private var serverThread: Thread? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        secretToken = intent?.getStringExtra("token") ?: "remotedial123"
        startForeground(NOTIFICATION_ID, buildNotification("Listening on port $PORT..."))
        startServer()
        isRunning = true
        return START_STICKY
    }

    private fun startServer() {
        serverThread = Thread {
            try {
                serverSocket = ServerSocket(PORT)
                broadcastLog("✅ Server started on port $PORT")
                Log.d("SocketServer", "Server started on port $PORT")

                while (!Thread.currentThread().isInterrupted) {
                    try {
                        val client: Socket = serverSocket!!.accept()
                        handleClient(client)
                    } catch (e: Exception) {
                        if (!Thread.currentThread().isInterrupted) {
                            Log.e("SocketServer", "Client error: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("SocketServer", "Server error: ${e.message}")
                broadcastLog("❌ Server error: ${e.message}")
            }
        }
        serverThread?.start()
    }

    private fun handleClient(client: Socket) {
        Thread {
            try {
                val reader = BufferedReader(InputStreamReader(client.getInputStream()))
                val writer = PrintWriter(client.getOutputStream(), true)
                val clientIp = client.inetAddress.hostAddress

                val rawMessage = reader.readLine()
                Log.d("SocketServer", "Received from $clientIp: $rawMessage")

                if (rawMessage.isNullOrEmpty()) {
                    writer.println(gson.toJson(ResponseMessage("ERROR", "Empty message")))
                    return@Thread
                }

                val command = try {
                    gson.fromJson(rawMessage, CommandMessage::class.java)
                } catch (e: Exception) {
                    writer.println(gson.toJson(ResponseMessage("ERROR", "Invalid JSON")))
                    broadcastLog("⚠️ Invalid command from $clientIp")
                    return@Thread
                }

                // Validate token
                if (command.token != secretToken) {
                    writer.println(gson.toJson(ResponseMessage("ERROR", "Invalid token")))
                    broadcastLog("🚫 Rejected command from $clientIp — wrong token")
                    return@Thread
                }

                // Process command
                when (command.action) {
                    "PING" -> {
                        writer.println(gson.toJson(ResponseMessage("PONG", "Server is alive")))
                        broadcastLog("🏓 Ping from $clientIp")
                    }

                    "DIAL" -> {
                        val number = command.payload
                        if (number.isBlank()) {
                            writer.println(gson.toJson(ResponseMessage("ERROR", "No phone number")))
                            return@Thread
                        }
                        broadcastLog("📞 Dial command from $clientIp → $number")
                        writer.println(gson.toJson(ResponseMessage("OK", "Dialing $number")))

                        // Execute dial via Accessibility Service or direct intent
                        executeDial(number)
                        updateNotification("Last call: $number from $clientIp")
                    }

                    "HANGUP" -> {
                        broadcastLog("📵 Hangup command from $clientIp")
                        writer.println(gson.toJson(ResponseMessage("OK", "Hangup triggered")))
                        // Hangup via accessibility
                        RemoteDialAccessibilityService.instance?.performHangup()
                    }

                    else -> {
                        writer.println(gson.toJson(ResponseMessage("ERROR", "Unknown action")))
                        broadcastLog("❓ Unknown action '${command.action}' from $clientIp")
                    }
                }

                client.close()
            } catch (e: Exception) {
                Log.e("SocketServer", "Handle client error: ${e.message}")
            }
        }.start()
    }

    private fun executeDial(number: String) {
        // First try via Accessibility Service (can handle foreground restriction)
        val accessibilityService = RemoteDialAccessibilityService.instance
        if (accessibilityService != null) {
            accessibilityService.dialNumber(number)
        } else {
            // Fallback: direct intent (requires app in foreground on Android 10+)
            val dialIntent = Intent(Intent.ACTION_CALL).apply {
                data = android.net.Uri.parse("tel:$number")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            try {
                startActivity(dialIntent)
            } catch (e: Exception) {
                broadcastLog("❌ Failed to dial: ${e.message}")
                Log.e("SocketServer", "Dial failed: ${e.message}")
            }
        }
    }

    private fun broadcastLog(message: String) {
        val intent = Intent(ACTION_LOG).apply {
            putExtra(EXTRA_LOG, message)
        }
        sendBroadcast(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "RemoteDial Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "RemoteDial server running in background"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("RemoteDial Active")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        serverThread?.interrupt()
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            Log.e("SocketServer", "Error closing: ${e.message}")
        }
        broadcastLog("🛑 Server stopped")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
