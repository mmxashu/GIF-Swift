package com.remotedial

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.text.format.Formatter
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.gson.Gson
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    companion object {
        const val TAG = "MainActivity"
        const val REQUEST_CALL_PERMISSION = 101
        const val PORT = 8888
    }

    // Views
    private lateinit var rgMode: RadioGroup
    private lateinit var rbController: RadioButton
    private lateinit var rbTarget: RadioButton
    private lateinit var tvMyIp: TextView
    private lateinit var tvPort: TextView
    private lateinit var etToken: EditText
    private lateinit var layoutController: View
    private lateinit var layoutTarget: View

    // Controller views
    private lateinit var etTargetIp: EditText
    private lateinit var etPhoneNumber: EditText
    private lateinit var btnDial: Button
    private lateinit var btnPing: Button
    private lateinit var tvLog: TextView
    private lateinit var btnClearLog: Button

    // Target views
    private lateinit var tvServerStatus: TextView
    private lateinit var tvAccessibilityStatus: TextView
    private lateinit var tvCallPermStatus: TextView
    private lateinit var btnStartServer: Button
    private lateinit var btnStopServer: Button
    private lateinit var btnEnableAccessibility: Button
    private lateinit var btnRequestCallPerm: Button
    private lateinit var tvReceivedLog: TextView

    private val gson = Gson()
    private var controllerLog = StringBuilder()
    private var receivedLog = StringBuilder()

    private val logReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val msg = intent?.getStringExtra(SocketServerService.EXTRA_LOG) ?: return
            appendReceivedLog(msg)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        setupListeners()
        displayMyIp()
        registerReceiver(logReceiver, IntentFilter(SocketServerService.ACTION_LOG))
    }

    override fun onResume() {
        super.onResume()
        updateTargetStatusChecks()
    }

    private fun bindViews() {
        rgMode = findViewById(R.id.rgMode)
        rbController = findViewById(R.id.rbController)
        rbTarget = findViewById(R.id.rbTarget)
        tvMyIp = findViewById(R.id.tvMyIp)
        tvPort = findViewById(R.id.tvPort)
        etToken = findViewById(R.id.etToken)
        layoutController = findViewById(R.id.layoutController)
        layoutTarget = findViewById(R.id.layoutTarget)

        etTargetIp = findViewById(R.id.etTargetIp)
        etPhoneNumber = findViewById(R.id.etPhoneNumber)
        btnDial = findViewById(R.id.btnDial)
        btnPing = findViewById(R.id.btnPing)
        tvLog = findViewById(R.id.tvLog)
        btnClearLog = findViewById(R.id.btnClearLog)

        tvServerStatus = findViewById(R.id.tvServerStatus)
        tvAccessibilityStatus = findViewById(R.id.tvAccessibilityStatus)
        tvCallPermStatus = findViewById(R.id.tvCallPermStatus)
        btnStartServer = findViewById(R.id.btnStartServer)
        btnStopServer = findViewById(R.id.btnStopServer)
        btnEnableAccessibility = findViewById(R.id.btnEnableAccessibility)
        btnRequestCallPerm = findViewById(R.id.btnRequestCallPerm)
        tvReceivedLog = findViewById(R.id.tvReceivedLog)
    }

    private fun setupListeners() {
        rgMode.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbController -> {
                    layoutController.visibility = View.VISIBLE
                    layoutTarget.visibility = View.GONE
                }
                R.id.rbTarget -> {
                    layoutController.visibility = View.GONE
                    layoutTarget.visibility = View.VISIBLE
                    updateTargetStatusChecks()
                }
            }
        }

        btnDial.setOnClickListener { sendDialCommand() }
        btnPing.setOnClickListener { sendPingCommand() }
        btnClearLog.setOnClickListener {
            controllerLog.clear()
            tvLog.text = "Log cleared."
        }

        btnStartServer.setOnClickListener { startTargetServer() }
        btnStopServer.setOnClickListener { stopTargetServer() }

        btnEnableAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnRequestCallPerm.setOnClickListener {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CALL_PHONE),
                REQUEST_CALL_PERMISSION
            )
        }
    }

    private fun displayMyIp() {
        val wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val ipAddress = Formatter.formatIpAddress(wifiManager.connectionInfo.ipAddress)
        tvMyIp.text = "IP: $ipAddress"
        tvPort.text = "Port: $PORT  (Share with controller)"
    }

    // ─── CONTROLLER ─────────────────────────────────────────────────────────────

    private fun sendDialCommand() {
        val ip = etTargetIp.text.toString().trim()
        val number = etPhoneNumber.text.toString().trim()
        val token = etToken.text.toString().trim()

        if (ip.isEmpty()) { toast("Enter target device IP"); return }
        if (number.isEmpty()) { toast("Enter a phone number"); return }
        if (token.isEmpty()) { toast("Enter security token"); return }

        val cmd = CommandMessage(token = token, action = "DIAL", payload = number)
        sendCommand(ip, cmd) { response ->
            val status = if (response?.status == "OK") "✅" else "❌"
            appendControllerLog("$status DIAL → $number | ${response?.status}: ${response?.message}")
        }
    }

    private fun sendPingCommand() {
        val ip = etTargetIp.text.toString().trim()
        val token = etToken.text.toString().trim()

        if (ip.isEmpty()) { toast("Enter target device IP"); return }

        val cmd = CommandMessage(token = token, action = "PING")
        sendCommand(ip, cmd) { response ->
            val status = if (response?.status == "PONG") "🟢" else "🔴"
            appendControllerLog("$status PING → $ip | ${response?.status}: ${response?.message}")
        }
    }

    private fun sendCommand(
        targetIp: String,
        command: CommandMessage,
        onResult: (ResponseMessage?) -> Unit
    ) {
        appendControllerLog("⏳ Sending ${command.action} to $targetIp...")

        Thread {
            var response: ResponseMessage? = null
            try {
                val socket = Socket(targetIp, PORT).apply { soTimeout = 5000 }
                val writer = socket.getOutputStream().bufferedWriter()
                val reader = socket.getInputStream().bufferedReader()

                writer.write(gson.toJson(command))
                writer.newLine()
                writer.flush()

                val rawResponse = reader.readLine()
                response = gson.fromJson(rawResponse, ResponseMessage::class.java)
                socket.close()
            } catch (e: Exception) {
                Log.e(TAG, "Send command error: ${e.message}")
                response = ResponseMessage("ERROR", e.message ?: "Connection failed")
            }

            val finalResponse = response
            runOnUiThread { onResult(finalResponse) }
        }.start()
    }

    private fun appendControllerLog(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        controllerLog.insert(0, "[$time] $msg\n")
        tvLog.text = controllerLog.toString()
    }

    // ─── TARGET ──────────────────────────────────────────────────────────────────

    private fun startTargetServer() {
        val token = etToken.text.toString().trim()
        if (token.isEmpty()) { toast("Enter a security token first"); return }

        val intent = Intent(this, SocketServerService::class.java).apply {
            putExtra("token", token)
        }
        ContextCompat.startForegroundService(this, intent)

        btnStartServer.visibility = View.GONE
        btnStopServer.visibility = View.VISIBLE
        tvServerStatus.text = "🟢 Server: Running on port $PORT"
        tvServerStatus.setTextColor(ContextCompat.getColor(this, R.color.success))
        appendReceivedLog("🚀 Server started")
    }

    private fun stopTargetServer() {
        stopService(Intent(this, SocketServerService::class.java))
        btnStartServer.visibility = View.VISIBLE
        btnStopServer.visibility = View.GONE
        tvServerStatus.text = "⚪ Server: Stopped"
        tvServerStatus.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
    }

    private fun updateTargetStatusChecks() {
        // Check Accessibility Service
        val accessibilityEnabled = isAccessibilityServiceEnabled()
        if (accessibilityEnabled) {
            tvAccessibilityStatus.text = "🟢 Accessibility: Enabled"
            tvAccessibilityStatus.setTextColor(ContextCompat.getColor(this, R.color.success))
            btnEnableAccessibility.visibility = View.GONE
        } else {
            tvAccessibilityStatus.text = "🔴 Accessibility: Not Enabled"
            tvAccessibilityStatus.setTextColor(ContextCompat.getColor(this, R.color.error))
            btnEnableAccessibility.visibility = View.VISIBLE
        }

        // Check CALL_PHONE permission
        val callPermGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        if (callPermGranted) {
            tvCallPermStatus.text = "🟢 CALL_PHONE: Granted"
            tvCallPermStatus.setTextColor(ContextCompat.getColor(this, R.color.success))
            btnRequestCallPerm.visibility = View.GONE
        } else {
            tvCallPermStatus.text = "🔴 CALL_PHONE: Not Granted"
            tvCallPermStatus.setTextColor(ContextCompat.getColor(this, R.color.error))
            btnRequestCallPerm.visibility = View.VISIBLE
        }

        // Server status
        if (SocketServerService.isRunning) {
            tvServerStatus.text = "🟢 Server: Running on port $PORT"
            tvServerStatus.setTextColor(ContextCompat.getColor(this, R.color.success))
            btnStartServer.visibility = View.GONE
            btnStopServer.visibility = View.VISIBLE
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val serviceName = "${packageName}/${RemoteDialAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(":").any {
            it.equals(serviceName, ignoreCase = true)
        }
    }

    private fun appendReceivedLog(msg: String) {
        runOnUiThread {
            val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            receivedLog.insert(0, "[$time] $msg\n")
            tvReceivedLog.text = receivedLog.toString()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CALL_PERMISSION) {
            updateTargetStatusChecks()
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                toast("CALL_PHONE permission granted ✅")
            } else {
                toast("Permission denied ❌")
            }
        }
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(logReceiver) } catch (e: Exception) { /* ignore */ }
    }
}
