package com.remotedial

data class CommandMessage(
    val token: String,
    val action: String,       // "DIAL", "PING", "HANGUP"
    val payload: String = ""  // phone number for DIAL
)

data class ResponseMessage(
    val status: String,       // "OK", "ERROR", "PONG"
    val message: String = ""
)
