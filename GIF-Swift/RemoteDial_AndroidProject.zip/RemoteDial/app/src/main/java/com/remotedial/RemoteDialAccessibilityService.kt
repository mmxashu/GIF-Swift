package com.remotedial

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RemoteDialAccessibilityService : AccessibilityService() {

    companion object {
        var instance: RemoteDialAccessibilityService? = null
        const val TAG = "RemoteDialA11y"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Accessibility Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Monitor call state changes if needed
        event?.let {
            when (it.eventType) {
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                    Log.d(TAG, "Window changed: ${it.packageName}")
                }
            }
        }
    }

    fun dialNumber(number: String) {
        Log.d(TAG, "Dialing: $number")
        try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$number")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            applicationContext.startActivity(intent)
            Log.d(TAG, "Dial intent sent for: $number")
        } catch (e: SecurityException) {
            Log.e(TAG, "CALL_PHONE permission denied: ${e.message}")
            // Try ACTION_DIAL as fallback (opens dialer without auto-calling)
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$number")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            applicationContext.startActivity(dialIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Dial failed: ${e.message}")
        }
    }

    fun performHangup() {
        // Try to find and click the end call button
        val root = rootInActiveWindow ?: return
        findAndClickEndCall(root)
    }

    private fun findAndClickEndCall(node: AccessibilityNodeInfo): Boolean {
        val endCallLabels = listOf("end", "hang up", "end call", "decline")

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val desc = child.contentDescription?.toString()?.lowercase() ?: ""
            val text = child.text?.toString()?.lowercase() ?: ""

            if (endCallLabels.any { desc.contains(it) || text.contains(it) }) {
                child.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return true
            }

            if (findAndClickEndCall(child)) return true
        }
        return false
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.d(TAG, "Accessibility Service destroyed")
    }
}
