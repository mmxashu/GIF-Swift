# 📱 RemoteDial — Remote Call Control over WiFi

Control one Android phone to dial calls on another Android phone over the same WiFi network.

---

## 🏗️ Project Structure

```
RemoteDial/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/remotedial/
│       │   ├── MainActivity.kt                    ← Main UI (Controller + Target modes)
│       │   ├── CommandMessage.kt                  ← Data models
│       │   ├── SocketServerService.kt             ← Background TCP server (Target device)
│       │   └── RemoteDialAccessibilityService.kt  ← Executes dial commands
│       └── res/
│           ├── layout/activity_main.xml
│           ├── xml/accessibility_service_config.xml
│           ├── values/strings.xml
│           ├── values/styles.xml
│           └── drawable/...
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 📲 How to Build & Install

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Kotlin 1.9.0
- Two Android phones on the same WiFi network (Android 6.0+ / API 23+)

### Steps
1. Open Android Studio → **Open** → Select the `RemoteDial` folder
2. Wait for Gradle sync to complete
3. Connect **both** Android devices via USB
4. Run → **Run 'app'** — install on BOTH devices

---

## ⚙️ Setup Instructions

### On the TARGET Device (the phone that will make the call)

1. Open RemoteDial app
2. Select **📱 Target** mode
3. Tap **"Grant CALL_PHONE Permission"** → Allow
4. Tap **"Enable Accessibility Service"** → Find "RemoteDial" → Toggle ON
5. Tap **"▶ START SERVER"**
6. Note the **IP address** shown (e.g. `192.168.1.105`)
7. Make sure both devices have the **same Security Token**

### On the CONTROLLER Device (the phone sending commands)

1. Open RemoteDial app
2. Select **🎮 Controller** mode
3. Enter the **Target IP** (from step 6 above)
4. Enter the **Security Token** (must match target device)
5. Enter a phone number
6. Tap **"📞 DIAL REMOTELY"**

---

## 🔐 Security

- All commands are authenticated with a **secret token**
- Commands without matching token are **rejected**
- Both devices must be on **same WiFi network**
- Token is configurable in the UI

---

## 🌐 How It Works

```
Controller Phone                    Target Phone
     |                                   |
     |  JSON via TCP port 8888           |
     |-------- {"action":"DIAL", ------->|
     |           "token":"...",          |
     |           "payload":"+1234"}      |
     |                              SocketServerService
     |                              validates token
     |                              calls dialNumber()
     |                                   |
     |                              AccessibilityService
     |                              fires ACTION_CALL intent
     |                                   |
     |<-------- {"status":"OK"} ---------|
```

### Commands Supported
| Command | Description |
|---------|-------------|
| `DIAL`  | Dials a phone number on the target device |
| `PING`  | Tests connection to target device |
| `HANGUP`| Attempts to end an active call |

---

## ⚠️ Limitations

| Limitation | Details |
|-----------|---------|
| Same WiFi required | Both devices must be on the same network |
| Manual permissions | Accessibility Service must be enabled by user |
| Android 10+ background | App uses foreground service to stay alive |
| CALL_PHONE permission | Must be explicitly granted by user |
| Not for background calls | User will see the call happening on screen |

---

## 🛠️ Troubleshooting

**"Connection refused"**
→ Make sure server is started on the target device
→ Check both devices are on same WiFi
→ Check IP address is correct

**"Invalid token"**
→ Ensure the same token is set on both devices

**"Dial failed"**
→ Ensure CALL_PHONE permission is granted on target device
→ Ensure Accessibility Service is enabled

**Server doesn't stay running**
→ Disable battery optimization for RemoteDial app
→ Settings → Battery → RemoteDial → Unrestricted

---

## 📋 Permissions Required

| Permission | Why |
|-----------|-----|
| `CALL_PHONE` | To initiate phone calls |
| `INTERNET` | TCP socket communication |
| `ACCESS_WIFI_STATE` | To display device IP address |
| `FOREGROUND_SERVICE` | Keep server alive in background |
| Accessibility Service | Execute dial commands from background |
