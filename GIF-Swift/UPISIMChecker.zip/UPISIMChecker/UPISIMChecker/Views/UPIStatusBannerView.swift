import SwiftUI

struct UPIStatusBannerView: View {
    @ObservedObject var vm: SIMViewModel

    private var status: SIMPresenceStatus {
        if vm.report?.isSimulator == true { return .simulatorMode }
        return vm.upiCapable ? .inserted : .notInserted
    }

    var body: some View {
        VStack(spacing: 0) {
            // Main status area
            HStack(spacing: 16) {
                // Big status icon
                ZStack {
                    Circle()
                        .fill(status.color.opacity(0.15))
                        .frame(width: 64, height: 64)
                    Image(systemName: status.systemIcon)
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundColor(status.color)
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text(status.title)
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .foregroundColor(AppTheme.textPrimary)
                    Text(status.subtitle)
                        .font(.system(size: 13))
                        .foregroundColor(AppTheme.textSecondary)

                    // UPI badge
                    HStack(spacing: 6) {
                        Circle()
                            .fill(vm.upiCapable ? AppTheme.green : AppTheme.red)
                            .frame(width: 6, height: 6)
                        Text(vm.upiCapable ? "UPI transactions enabled" : "UPI transactions blocked")
                            .font(.system(size: 11, weight: .medium, design: .monospaced))
                            .foregroundColor(vm.upiCapable ? AppTheme.green : AppTheme.red)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(vm.upiCapable ? AppTheme.green.opacity(0.12) : AppTheme.red.opacity(0.12))
                    .cornerRadius(6)
                }

                Spacer()
            }
            .padding(20)

            // Summary row
            Divider()
                .background(AppTheme.border)
                .padding(.horizontal, 20)

            HStack(spacing: 0) {
                SummaryMetric(
                    label: "SIM slots",
                    value: "\(vm.report?.slots.count ?? 0)",
                    color: AppTheme.blue
                )
                Divider()
                    .frame(height: 32)
                    .background(AppTheme.border)
                SummaryMetric(
                    label: "Active SIMs",
                    value: "\(vm.report?.activeSIMCount ?? 0)",
                    color: AppTheme.green
                )
                Divider()
                    .frame(height: 32)
                    .background(AppTheme.border)
                SummaryMetric(
                    label: "iOS version",
                    value: vm.iosVersion,
                    color: AppTheme.purple
                )
            }
            .padding(.vertical, 14)
        }
        .cardStyle()
    }
}

struct SummaryMetric: View {
    let label: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .foregroundColor(color)
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(AppTheme.textTertiary)
        }
        .frame(maxWidth: .infinity)
    }
}
