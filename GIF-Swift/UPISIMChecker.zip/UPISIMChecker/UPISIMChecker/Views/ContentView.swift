import SwiftUI

struct ContentView: View {
    @StateObject private var vm = SIMViewModel()

    var body: some View {
        ZStack {
            AppTheme.bg0.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    HeaderView(vm: vm)
                    
                    VStack(spacing: 16) {
                        UPIStatusBannerView(vm: vm)
                        SlotPickerView(vm: vm)
                        if let slot = vm.selectedSlot {
                            SIMSlotDetailView(slot: slot)
                        }
                        NetworkInfoView(vm: vm)
                        CarrierRegistryView()
                        DetectionInfoView(vm: vm)
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 40)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

#Preview {
    ContentView()
}
