import SwiftUI

// MARK: - App Design Tokens
enum AppTheme {
    // Background layers
    static let bg0 = Color("BG0")      // deepest
    static let bg1 = Color("BG1")      // card
    static let bg2 = Color("BG2")      // cell

    // Text
    static let textPrimary   = Color("TextPrimary")
    static let textSecondary = Color("TextSecondary")
    static let textTertiary  = Color("TextTertiary")

    // Semantic
    static let green  = Color("AccentGreen")
    static let red    = Color("AccentRed")
    static let amber  = Color("AccentAmber")
    static let blue   = Color("AccentBlue")
    static let purple = Color("AccentPurple")

    // Borders
    static let border = Color("Border")
    static let borderSubtle = Color("BorderSubtle")

    // Carrier colors
    static func carrier(_ hex: String) -> Color {
        Color(hex: hex) ?? .blue
    }
}

// MARK: - Color from Hex
extension Color {
    init?(hex: String) {
        var h = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        if h.hasPrefix("#") { h.removeFirst() }
        guard h.count == 6, let val = UInt64(h, radix: 16) else { return nil }
        self.init(
            red:   Double((val >> 16) & 0xFF) / 255,
            green: Double((val >>  8) & 0xFF) / 255,
            blue:  Double( val        & 0xFF) / 255
        )
    }
}

// MARK: - Reusable View Modifiers
struct CardStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background(AppTheme.bg1)
            .cornerRadius(16)
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(AppTheme.border, lineWidth: 0.5))
    }
}

struct CellStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background(AppTheme.bg2)
            .cornerRadius(10)
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(AppTheme.borderSubtle, lineWidth: 0.5))
    }
}

extension View {
    func cardStyle() -> some View { modifier(CardStyle()) }
    func cellStyle() -> some View { modifier(CellStyle()) }
}

// MARK: - Status Color helper
extension SIMPresenceStatus {
    var color: Color {
        switch self {
        case .inserted:      return AppTheme.green
        case .notInserted:   return AppTheme.red
        case .unknown:       return AppTheme.amber
        case .simulatorMode: return AppTheme.amber
        }
    }
    var bgColor: Color {
        switch self {
        case .inserted:      return AppTheme.green.opacity(0.12)
        case .notInserted:   return AppTheme.red.opacity(0.12)
        case .unknown:       return AppTheme.amber.opacity(0.12)
        case .simulatorMode: return AppTheme.amber.opacity(0.12)
        }
    }
    var systemIcon: String {
        switch self {
        case .inserted:      return "checkmark.circle.fill"
        case .notInserted:   return "xmark.circle.fill"
        case .unknown:       return "questionmark.circle.fill"
        case .simulatorMode: return "exclamationmark.triangle.fill"
        }
    }
}
