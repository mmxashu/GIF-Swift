import SwiftUI

struct HeaderView: View {
    @ObservedObject var vm: SIMViewModel

    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .center, spacing: 14) {
                // App icon area
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(AppTheme.blue.opacity(0.15))
                        .frame(width: 48, height: 48)
                    Image(systemName: "simcard.2.fill")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(AppTheme.blue)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text("UPI SIM Checker")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundColor(AppTheme.textPrimary)
                    Text("India carrier · iOS \(vm.iosVersion)")
                        .font(.system(size: 12, weight: .medium, design: .monospaced))
                        .foregroundColor(AppTheme.textTertiary)
                }

                Spacer()

                Button(action: { vm.refresh() }) {
                    ZStack {
                        Circle()
                            .fill(AppTheme.bg1)
                            .frame(width: 38, height: 38)
                            .overlay(Circle().stroke(AppTheme.border, lineWidth: 0.5))
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(AppTheme.blue)
                            .rotationEffect(.degrees(vm.isLoading ? 360 : 0))
                            .animation(vm.isLoading ? .linear(duration: 0.7).repeatForever(autoreverses: false) : .default, value: vm.isLoading)
                    }
                }
                .disabled(vm.isLoading)
            }
            .padding(.horizontal, 16)
            .padding(.top, 60)
            .padding(.bottom, 24)
        }
    }
}
