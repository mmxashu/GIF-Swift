import SwiftUI

// MARK: - Slot Picker
struct SlotPickerView: View {
    @ObservedObject var vm: SIMViewModel

    var body: some View {
        guard let report = vm.report, report.slots.count > 1 else { return AnyView(EmptyView()) }

        return AnyView(
            HStack(spacing: 8) {
                ForEach(report.slots) { slot in
                    Button(action: { vm.selectedSlotID = slot.id }) {
                        HStack(spacing: 8) {
                            Image(systemName: "simcard.fill")
                                .font(.system(size: 12))
                            Text("SIM \(slot.id)")
                                .font(.system(size: 13, weight: .medium))
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 9)
                        .frame(maxWidth: .infinity)
                        .background(vm.selectedSlotID == slot.id ? AppTheme.blue.opacity(0.15) : AppTheme.bg1)
                        .foregroundColor(vm.selectedSlotID == slot.id ? AppTheme.blue : AppTheme.textSecondary)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(vm.selectedSlotID == slot.id ? AppTheme.blue.opacity(0.4) : AppTheme.border, lineWidth: 0.8)
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        )
    }
}

// MARK: - SIM Slot Detail
struct SIMSlotDetailView: View {
    let slot: SIMSlotInfo

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Slot header
            HStack(spacing: 12) {
                Image(systemName: "simcard.fill")
                    .font(.system(size: 18))
                    .foregroundColor(AppTheme.blue)
                VStack(alignment: .leading, spacing: 2) {
                    Text("SIM Slot \(slot.id)")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(AppTheme.textPrimary)
                    Text(slot.slotKey)
                        .font(.system(size: 10, weight: .regular, design: .monospaced))
                        .foregroundColor(AppTheme.textTertiary)
                }
                Spacer()
                StatusPill(status: slot.presenceStatus)
            }
            .padding(16)

            Divider().background(AppTheme.border)

            // Detail rows
            Group {
                DetailRow(icon: "antenna.radiowaves.left.and.right",
                          label: "Network generation",
                          value: slot.networkGeneration.rawValue,
                          valueColor: genColor(slot.networkGeneration))

                DetailRow(icon: "cpu",
                          label: "Radio access technology",
                          value: friendlyRAT(slot.radioAccessTech),
                          valueColor: AppTheme.textPrimary)

                DetailRow(icon: "wrench.and.screwdriver",
                          label: "Detection API",
                          value: slot.detectionAPI,
                          valueColor: AppTheme.blue,
                          mono: true)

                if let carrier = slot.matchedCarrier {
                    DetailRow(icon: "building.2",
                              label: "Matched carrier",
                              value: carrier.name,
                              valueColor: AppTheme.carrier(carrier.colorHex))
                    DetailRow(icon: "number",
                              label: "MCC / MNC",
                              value: "\(carrier.mcc) / \(carrier.mnc)",
                              valueColor: AppTheme.purple,
                              mono: true)
                } else {
                    DetailRow(icon: "building.2",
                              label: "Carrier match",
                              value: "Not available (iOS 16+ deprecation)",
                              valueColor: AppTheme.amber)
                }
            }
        }
        .cardStyle()
    }

    private func genColor(_ gen: NetworkGeneration) -> Color {
        switch gen {
        case .gen2G:   return AppTheme.amber
        case .gen3G:   return AppTheme.amber
        case .gen4G:   return AppTheme.green
        case .gen5G:   return AppTheme.blue
        case .unknown: return AppTheme.textTertiary
        }
    }

    private func friendlyRAT(_ rat: String?) -> String {
        guard let rat = rat else { return "Not available" }
        let map: [String: String] = [
            "CTRadioAccessTechnologyGPRS":        "GPRS (2G)",
            "CTRadioAccessTechnologyEdge":        "EDGE (2G)",
            "CTRadioAccessTechnologyWCDMA":       "WCDMA (3G)",
            "CTRadioAccessTechnologyHSDPA":       "HSDPA (3G)",
            "CTRadioAccessTechnologyHSUPA":       "HSUPA (3G)",
            "CTRadioAccessTechnologyCDMA1x":      "CDMA 1x (2G)",
            "CTRadioAccessTechnologyCDMAEVDORev0":"EVDO Rev0 (3G)",
            "CTRadioAccessTechnologyCDMAEVDORevA":"EVDO RevA (3G)",
            "CTRadioAccessTechnologyCDMAEVDORevB":"EVDO RevB (3G)",
            "CTRadioAccessTechnologyeHRPD":       "eHRPD (3G)",
            "CTRadioAccessTechnologyLTE":         "LTE (4G)",
            "CTRadioAccessTechnologyNRNSA":       "NR Non-Standalone (5G)",
            "CTRadioAccessTechnologyNR":          "NR Standalone (5G)",
        ]
        return map[rat] ?? rat
    }
}

// MARK: - Status Pill
struct StatusPill: View {
    let status: SIMPresenceStatus

    var body: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(status.color)
                .frame(width: 6, height: 6)
            Text(status.title)
                .font(.system(size: 11, weight: .medium, design: .monospaced))
                .foregroundColor(status.color)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 5)
        .background(status.bgColor)
        .cornerRadius(20)
        .overlay(Capsule().stroke(status.color.opacity(0.3), lineWidth: 0.8))
    }
}

// MARK: - Detail Row
struct DetailRow: View {
    let icon: String
    let label: String
    let value: String
    let valueColor: Color
    var mono: Bool = false

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 13))
                .foregroundColor(AppTheme.textTertiary)
                .frame(width: 20)
                .padding(.top, 1)

            Text(label)
                .font(.system(size: 13))
                .foregroundColor(AppTheme.textSecondary)
                .frame(width: 160, alignment: .leading)

            Spacer()

            Text(value)
                .font(mono
                    ? .system(size: 12, weight: .medium, design: .monospaced)
                    : .system(size: 13, weight: .medium))
                .foregroundColor(valueColor)
                .multilineTextAlignment(.trailing)
                .lineLimit(2)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(AppTheme.bg1)
        .overlay(
            Rectangle()
                .fill(AppTheme.border)
                .frame(height: 0.5),
            alignment: .top
        )
    }
}
