import SwiftUI
import CoreTelephony

// MARK: - Network Info View
struct NetworkInfoView: View {
    @ObservedObject var vm: SIMViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionHeader(title: "Network status", icon: "antenna.radiowaves.left.and.right")

            if let report = vm.report {
                ForEach(report.slots) { slot in
                    HStack(spacing: 12) {
                        // Network gen badge
                        Text(slot.networkGenLabel)
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .frame(width: 44, height: 28)
                            .background(genBadgeColor(slot.networkGeneration))
                            .cornerRadius(7)

                        VStack(alignment: .leading, spacing: 3) {
                            Text("SIM \(slot.id) — \(slot.presenceStatus.title)")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(AppTheme.textPrimary)
                            Text(slot.radioAccessTech.map { friendlyShort($0) } ?? "No signal data")
                                .font(.system(size: 11, design: .monospaced))
                                .foregroundColor(AppTheme.textTertiary)
                        }

                        Spacer()

                        // Signal bars
                        SignalBarsView(generation: slot.networkGeneration)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)

                    if slot.id != report.slots.last?.id {
                        Divider().background(AppTheme.border).padding(.horizontal, 16)
                    }
                }
            } else {
                Text("Scanning…")
                    .font(.system(size: 13))
                    .foregroundColor(AppTheme.textTertiary)
                    .padding(16)
            }
        }
        .cardStyle()
    }

    private func genBadgeColor(_ gen: NetworkGeneration) -> Color {
        switch gen {
        case .gen5G:   return AppTheme.blue
        case .gen4G:   return AppTheme.green
        case .gen3G:   return AppTheme.amber
        case .gen2G:   return AppTheme.red
        case .unknown: return AppTheme.textTertiary
        }
    }

    private func friendlyShort(_ rat: String) -> String {
        let map: [String: String] = [
            "CTRadioAccessTechnologyLTE":     "LTE · Long-Term Evolution",
            "CTRadioAccessTechnologyNR":      "NR · 5G Standalone",
            "CTRadioAccessTechnologyNRNSA":   "NRNSA · 5G Non-Standalone",
            "CTRadioAccessTechnologyWCDMA":   "WCDMA · 3G Wideband",
            "CTRadioAccessTechnologyHSDPA":   "HSDPA · 3G High-Speed",
            "CTRadioAccessTechnologyEdge":    "EDGE · 2G Enhanced",
            "CTRadioAccessTechnologyGPRS":    "GPRS · 2G General Packet",
        ]
        return map[rat] ?? rat
    }
}

// MARK: - Signal Bars
struct SignalBarsView: View {
    let generation: NetworkGeneration

    private var filledBars: Int {
        switch generation {
        case .gen5G:   return 5
        case .gen4G:   return 4
        case .gen3G:   return 3
        case .gen2G:   return 2
        case .unknown: return 0
        }
    }

    private var barColor: Color {
        switch generation {
        case .gen5G:   return AppTheme.blue
        case .gen4G:   return AppTheme.green
        case .gen3G:   return AppTheme.amber
        case .gen2G:   return AppTheme.red
        case .unknown: return AppTheme.textTertiary
        }
    }

    var body: some View {
        HStack(alignment: .bottom, spacing: 3) {
            ForEach(0..<5, id: \.self) { i in
                RoundedRectangle(cornerRadius: 2)
                    .fill(i < filledBars ? barColor : AppTheme.border)
                    .frame(width: 4, height: CGFloat(5 + i * 4))
            }
        }
        .frame(height: 22)
    }
}

// MARK: - Indian Carrier Registry View
struct CarrierRegistryView: View {
    @State private var expanded = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button(action: { withAnimation(.spring(duration: 0.3)) { expanded.toggle() } }) {
                HStack {
                    SectionHeader(title: "Indian carrier registry (MCC/MNC)", icon: "building.2.fill")
                    Spacer()
                    Image(systemName: expanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(AppTheme.textTertiary)
                        .padding(.trailing, 16)
                }
            }
            .buttonStyle(.plain)

            if expanded {
                Divider().background(AppTheme.border)

                VStack(spacing: 0) {
                    // Header
                    HStack {
                        Text("Carrier")
                            .frame(maxWidth: .infinity, alignment: .leading)
                        Text("MCC")
                            .frame(width: 48, alignment: .center)
                        Text("MNC")
                            .frame(width: 48, alignment: .center)
                    }
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(AppTheme.textTertiary)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(AppTheme.bg2)

                    ForEach(IndianCarrier.all) { carrier in
                        HStack {
                            HStack(spacing: 8) {
                                Circle()
                                    .fill(AppTheme.carrier(carrier.colorHex))
                                    .frame(width: 8, height: 8)
                                Text(carrier.name)
                                    .font(.system(size: 13))
                                    .foregroundColor(AppTheme.textPrimary)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)

                            Text(carrier.mcc)
                                .font(.system(size: 12, weight: .medium, design: .monospaced))
                                .foregroundColor(AppTheme.purple)
                                .frame(width: 48, alignment: .center)

                            Text(carrier.mnc)
                                .font(.system(size: 12, weight: .medium, design: .monospaced))
                                .foregroundColor(AppTheme.blue)
                                .frame(width: 48, alignment: .center)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(AppTheme.bg1)
                        .overlay(
                            Rectangle()
                                .fill(AppTheme.border)
                                .frame(height: 0.5),
                            alignment: .top
                        )
                    }

                    // Info note
                    HStack(spacing: 8) {
                        Image(systemName: "info.circle")
                            .font(.system(size: 12))
                        Text("All Indian carriers share MCC 404. MNC differentiates each operator.")
                            .font(.system(size: 11))
                            .foregroundColor(AppTheme.textTertiary)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(AppTheme.blue.opacity(0.06))
                }
            }
        }
        .cardStyle()
    }
}

// MARK: - Detection Info View
struct DetectionInfoView: View {
    @ObservedObject var vm: SIMViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            SectionHeader(title: "Detection info", icon: "doc.text.magnifyingglass")

            Group {
                InfoRow(label: "Strategy",
                        value: vm.detectionStrategy,
                        mono: true)
                InfoRow(label: "Scanned at",
                        value: vm.formattedDate,
                        mono: false)
                InfoRow(label: "Platform",
                        value: vm.report?.isSimulator == true ? "Simulator (inaccurate)" : "Physical device",
                        valueColor: vm.report?.isSimulator == true ? AppTheme.amber : AppTheme.green)
                InfoRow(label: "Entitlement required",
                        value: "com.apple.developer.upi-device-validation",
                        mono: true,
                        valueColor: AppTheme.purple)
                InfoRow(label: "Info.plist key",
                        value: "CarrierDescriptors [ MCC + MNC ]",
                        mono: true,
                        valueColor: AppTheme.blue)
            }
        }
        .cardStyle()
    }
}

struct InfoRow: View {
    let label: String
    let value: String
    var mono: Bool = false
    var valueColor: Color = AppTheme.textPrimary

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(AppTheme.textTertiary)
            Text(value)
                .font(mono
                      ? .system(size: 11, weight: .medium, design: .monospaced)
                      : .system(size: 13, weight: .medium))
                .foregroundColor(valueColor)
                .lineLimit(2)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.bg1)
        .overlay(
            Rectangle().fill(AppTheme.border).frame(height: 0.5),
            alignment: .top
        )
    }
}

// MARK: - Section Header
struct SectionHeader: View {
    let title: String
    let icon: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 13))
                .foregroundColor(AppTheme.textTertiary)
            Text(title.uppercased())
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(AppTheme.textTertiary)
                .tracking(0.8)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
