import Foundation

// MARK: - Indian Carrier Registry
struct IndianCarrier: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let shortName: String
    let mcc: String
    let mnc: String
    let colorHex: String

    static let all: [IndianCarrier] = [
        IndianCarrier(name: "Reliance Jio",         shortName: "Jio",     mcc: "404", mnc: "88",  colorHex: "#0066FF"),
        IndianCarrier(name: "Bharti Airtel",         shortName: "Airtel",  mcc: "404", mnc: "10",  colorHex: "#FF2B00"),
        IndianCarrier(name: "Bharti Airtel (2)",     shortName: "Airtel2", mcc: "404", mnc: "20",  colorHex: "#FF5500"),
        IndianCarrier(name: "Vi (Vodafone Idea)",    shortName: "Vi",      mcc: "404", mnc: "05",  colorHex: "#E60026"),
        IndianCarrier(name: "Vi (Idea)",             shortName: "Idea",    mcc: "404", mnc: "24",  colorHex: "#F7A800"),
        IndianCarrier(name: "BSNL",                  shortName: "BSNL",    mcc: "404", mnc: "07",  colorHex: "#0A6E3B"),
        IndianCarrier(name: "BSNL (2)",              shortName: "BSNL2",   mcc: "404", mnc: "04",  colorHex: "#0A6E3B"),
        IndianCarrier(name: "MTNL Delhi",            shortName: "MTNL",    mcc: "404", mnc: "68",  colorHex: "#8B0000"),
        IndianCarrier(name: "Tata Teleservices",     shortName: "Tata",    mcc: "404", mnc: "71",  colorHex: "#003366"),
    ]

    static func match(mcc: String?, mnc: String?) -> IndianCarrier? {
        guard let mcc = mcc, let mnc = mnc else { return nil }
        return all.first { $0.mcc == mcc && $0.mnc == mnc }
    }

    static func matchByMCC(_ mcc: String?) -> [IndianCarrier] {
        guard let mcc = mcc else { return [] }
        return all.filter { $0.mcc == mcc }
    }
}

// MARK: - Network Generation
enum NetworkGeneration: String, CaseIterable {
    case gen2G = "2G"
    case gen3G = "3G"
    case gen4G = "4G LTE"
    case gen5G = "5G"
    case unknown = "Unknown"

    var icon: String {
        switch self {
        case .gen2G:  return "antenna.radiowaves.left.and.right"
        case .gen3G:  return "antenna.radiowaves.left.and.right"
        case .gen4G:  return "chart.bar.fill"
        case .gen5G:  return "bolt.fill"
        case .unknown: return "questionmark.circle"
        }
    }
}

// MARK: - SIM Status
enum SIMPresenceStatus {
    case inserted
    case notInserted
    case unknown
    case simulatorMode

    var title: String {
        switch self {
        case .inserted:      return "SIM Detected"
        case .notInserted:   return "No SIM"
        case .unknown:       return "Unknown"
        case .simulatorMode: return "Simulator"
        }
    }

    var subtitle: String {
        switch self {
        case .inserted:      return "Registered SIM is present"
        case .notInserted:   return "No registered SIM found"
        case .unknown:       return "Cannot determine SIM status"
        case .simulatorMode: return "Run on device for accurate data"
        }
    }

    var isOK: Bool { self == .inserted }
}

// MARK: - SIM Slot Info
struct SIMSlotInfo: Identifiable {
    let id: Int
    let slotKey: String
    let presenceStatus: SIMPresenceStatus
    let radioAccessTech: String?
    let networkGeneration: NetworkGeneration
    let detectionAPI: String
    let matchedCarrier: IndianCarrier?

    var networkGenLabel: String { networkGeneration.rawValue }
}

// MARK: - Device SIM Report
struct DeviceSIMReport {
    let slots: [SIMSlotInfo]
    let detectedAt: Date
    let iosVersion: String
    let deviceModel: String
    let isSimulator: Bool
    let detectionStrategy: String

    var activeSlots: [SIMSlotInfo] { slots.filter { $0.presenceStatus == .inserted } }
    var activeSIMCount: Int { activeSlots.count }
    var isUPICapable: Bool { activeSIMCount > 0 }
    var primarySlot: SIMSlotInfo? { activeSlots.first }
}
