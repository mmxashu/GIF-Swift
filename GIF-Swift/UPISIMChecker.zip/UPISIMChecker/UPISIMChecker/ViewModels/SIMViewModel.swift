import Foundation
import Combine

@MainActor
final class SIMViewModel: ObservableObject {

    @Published var report: DeviceSIMReport? = nil
    @Published var isLoading: Bool = false
    @Published var selectedSlotID: Int? = nil

    private let service = SIMDetectionService.shared

    init() {
        refresh()
    }

    func refresh() {
        isLoading = true
        // Slight delay for UX polish
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            guard let self else { return }
            self.report = self.service.generateReport()
            if self.selectedSlotID == nil {
                self.selectedSlotID = self.report?.slots.first?.id
            }
            self.isLoading = false
        }
    }

    var selectedSlot: SIMSlotInfo? {
        guard let id = selectedSlotID else { return report?.slots.first }
        return report?.slots.first { $0.id == id }
    }

    var upiCapable: Bool {
        service.isUPICapableSIMPresent()
    }

    var iosVersion: String {
        report?.iosVersion ?? UIDevice.current.systemVersion
    }

    var detectionStrategy: String {
        report?.detectionStrategy ?? "—"
    }

    var formattedDate: String {
        guard let date = report?.detectedAt else { return "—" }
        let f = DateFormatter()
        f.dateFormat = "dd MMM yyyy, hh:mm:ss a"
        return f.string(from: date)
    }
}
