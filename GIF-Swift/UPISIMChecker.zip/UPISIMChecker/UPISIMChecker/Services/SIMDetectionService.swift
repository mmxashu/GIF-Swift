import Foundation
import CoreTelephony

// MARK: - SIM Detection Service
final class SIMDetectionService {

    static let shared = SIMDetectionService()
    private init() {}

    private let networkInfo = CTTelephonyNetworkInfo()

    // MARK: - Main Entry Point
    func generateReport() -> DeviceSIMReport {
        let isSimulator = checkIsSimulator()
        let strategy = detectionStrategy()
        let slots = detectAllSlots(isSimulator: isSimulator)

        return DeviceSIMReport(
            slots: slots,
            detectedAt: Date(),
            iosVersion: UIDevice.current.systemVersion,
            deviceModel: UIDevice.current.model,
            isSimulator: isSimulator,
            detectionStrategy: strategy
        )
    }

    // MARK: - iOS Version Strategy Selector
    private func detectionStrategy() -> String {
        if #available(iOS 18.0, *) {
            return "CTSubscriberInfo.isSIMInserted (iOS 18+)"
        } else if #available(iOS 12.0, *) {
            return "serviceCurrentRadioAccessTechnology (iOS 12–17)"
        } else {
            return "subscriberCellularProvider (Legacy)"
        }
    }

    // MARK: - Slot Detection Router
    private func detectAllSlots(isSimulator: Bool) -> [SIMSlotInfo] {
        if isSimulator {
            return simulatorSlots()
        }

        if #available(iOS 18.0, *) {
            return detectSlotsIOS18()
        } else if #available(iOS 12.0, *) {
            return detectSlotsIOS12()
        } else {
            return detectSlotsLegacy()
        }
    }

    // MARK: - iOS 18+ Detection (CTSubscriberInfo.isSIMInserted)
    @available(iOS 18.0, *)
    private func detectSlotsIOS18() -> [SIMSlotInfo] {
        let subscribers = CTSubscriberInfo().subscribers
        var slots: [SIMSlotInfo] = []
        let rat = networkInfo.serviceCurrentRadioAccessTechnology

        for (index, subscriber) in subscribers.enumerated() {
            let inserted = subscriber.isSIMInserted
            let slotKey = subscriber.identifier ?? "slot_\(index + 1)"
            let ratValue = rat?[slotKey]
            let gen = generation(from: ratValue)

            slots.append(SIMSlotInfo(
                id: index + 1,
                slotKey: slotKey,
                presenceStatus: inserted ? .inserted : .notInserted,
                radioAccessTech: ratValue,
                networkGeneration: gen,
                detectionAPI: "CTSubscriber.isSIMInserted",
                matchedCarrier: nil // MCC/MNC not readable post-iOS 16 deprecation
            ))
        }

        return ensureMinimumSlots(slots, api: "CTSubscriber.isSIMInserted")
    }

    // MARK: - iOS 12–17 Detection (serviceCurrentRadioAccessTechnology)
    @available(iOS 12.0, *)
    private func detectSlotsIOS12() -> [SIMSlotInfo] {
        guard let rat = networkInfo.serviceCurrentRadioAccessTechnology else {
            // nil = no SIM or no signal
            return [SIMSlotInfo(
                id: 1,
                slotKey: "slot_1",
                presenceStatus: .notInserted,
                radioAccessTech: nil,
                networkGeneration: .unknown,
                detectionAPI: "serviceCurrentRadioAccessTechnology",
                matchedCarrier: nil
            )]
        }

        var slots: [SIMSlotInfo] = []
        let providers = networkInfo.serviceSubscriberCellularProviders

        for (index, (key, ratValue)) in rat.enumerated() {
            let carrier = providers?[key]
            // mobileCountryCode is nil on iOS 16.4+ SDK (deprecated)
            // Best effort — may return nil on newer builds
            let mcc = carrier?.mobileCountryCode
            let mnc = carrier?.mobileNetworkCode
            let matched = IndianCarrier.match(mcc: mcc, mnc: mnc)
            let gen = generation(from: ratValue)
            let hasSIM = !ratValue.isEmpty

            slots.append(SIMSlotInfo(
                id: index + 1,
                slotKey: key,
                presenceStatus: hasSIM ? .inserted : .unknown,
                radioAccessTech: ratValue,
                networkGeneration: gen,
                detectionAPI: "serviceCurrentRadioAccessTechnology",
                matchedCarrier: matched
            ))
        }

        return ensureMinimumSlots(slots, api: "serviceCurrentRadioAccessTechnology")
    }

    // MARK: - Legacy Detection (< iOS 12)
    private func detectSlotsLegacy() -> [SIMSlotInfo] {
        let carrier = networkInfo.subscriberCellularProvider
        let mcc = carrier?.mobileCountryCode
        let mnc = carrier?.mobileNetworkCode
        let matched = IndianCarrier.match(mcc: mcc, mnc: mnc)
        let hasSIM = mcc != nil && !mcc!.isEmpty

        return [SIMSlotInfo(
            id: 1,
            slotKey: "slot_1",
            presenceStatus: hasSIM ? .inserted : .notInserted,
            radioAccessTech: networkInfo.currentRadioAccessTechnology,
            networkGeneration: generation(from: networkInfo.currentRadioAccessTechnology),
            detectionAPI: "subscriberCellularProvider (deprecated)",
            matchedCarrier: matched
        )]
    }

    // MARK: - Simulator Placeholder
    private func simulatorSlots() -> [SIMSlotInfo] {
        [
            SIMSlotInfo(
                id: 1,
                slotKey: "simulator_slot_1",
                presenceStatus: .simulatorMode,
                radioAccessTech: nil,
                networkGeneration: .unknown,
                detectionAPI: "N/A — Simulator",
                matchedCarrier: nil
            )
        ]
    }

    // MARK: - Helpers
    private func ensureMinimumSlots(_ slots: [SIMSlotInfo], api: String) -> [SIMSlotInfo] {
        if slots.isEmpty {
            return [SIMSlotInfo(
                id: 1,
                slotKey: "slot_1",
                presenceStatus: .notInserted,
                radioAccessTech: nil,
                networkGeneration: .unknown,
                detectionAPI: api,
                matchedCarrier: nil
            )]
        }
        return slots
    }

    private func checkIsSimulator() -> Bool {
        #if targetEnvironment(simulator)
        return true
        #else
        return false
        #endif
    }

    // MARK: - RAT → Network Generation Mapping
    func generation(from rat: String?) -> NetworkGeneration {
        guard let rat = rat else { return .unknown }

        switch rat {
        case CTRadioAccessTechnologyGPRS,
             CTRadioAccessTechnologyEdge,
             CTRadioAccessTechnologyCDMA1x:
            return .gen2G

        case CTRadioAccessTechnologyWCDMA,
             CTRadioAccessTechnologyHSDPA,
             CTRadioAccessTechnologyHSUPA,
             CTRadioAccessTechnologyCDMAEVDORev0,
             CTRadioAccessTechnologyCDMAEVDORevA,
             CTRadioAccessTechnologyCDMAEVDORevB,
             CTRadioAccessTechnologyeHRPD:
            return .gen3G

        case CTRadioAccessTechnologyLTE:
            return .gen4G

        default:
            if #available(iOS 14.1, *) {
                switch rat {
                case CTRadioAccessTechnologyNRNSA,
                     CTRadioAccessTechnologyNR:
                    return .gen5G
                default:
                    break
                }
            }
            return .unknown
        }
    }

    // MARK: - UPI Security Check (Production Use)
    func isUPICapableSIMPresent() -> Bool {
        #if targetEnvironment(simulator)
        // Return true in Debug/Simulator to allow UI testing
        #if DEBUG
        return true
        #else
        return false
        #endif
        #endif

        if #available(iOS 18.0, *) {
            return CTSubscriberInfo().subscribers.contains { $0.isSIMInserted }
        } else if #available(iOS 12.0, *) {
            let rat = networkInfo.serviceCurrentRadioAccessTechnology
            return !(rat?.isEmpty ?? true)
        }
        return false
    }
}
