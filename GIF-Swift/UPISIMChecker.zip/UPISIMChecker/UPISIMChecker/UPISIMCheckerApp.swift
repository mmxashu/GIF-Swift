import SwiftUI

@main
struct UPISIMCheckerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
