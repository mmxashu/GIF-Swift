# UPI SIM Checker

A production-ready iOS app to detect Indian carrier SIM presence for UPI payment security validation.

---

## Requirements

| Requirement | Value |
|---|---|
| Xcode | 16+ |
| iOS Deployment Target | 16.0+ |
| Swift | 5.0+ |
| Device | Physical iPhone only (Simulator always returns false) |

---

## Before You Build — Apple Entitlement Requests

Two entitlements must be approved by Apple before `isSIMInserted` works correctly:

### 1. UPI Device Validation (India-specific)
- **Key:** `com.apple.developer.upi-device-validation`
- **Where:** developer.apple.com → Certificates, Identifiers & Profiles → Your App ID → Capability Requests
- **Who:** Account Holder role only

### 2. SIM Inserted for Wireless Carriers
- **Key:** `com.apple.developer.coretelephony.sim-inserted`
- **Where:** Xcode → Target → Signing & Capabilities → + Capability → "SIM Inserted for Wireless Carriers"
- **Note:** Only enabled once the first entitlement above is approved

---

## Project Structure

```
UPISIMChecker/
├── UPISIMCheckerApp.swift            App entry point
├── Info.plist                        CarrierDescriptors (MCC/MNC for all Indian carriers)
├── UPISIMChecker.entitlements        UPI + SIM entitlement keys
│
├── Models/
│   └── SIMModels.swift               IndianCarrier, SIMSlotInfo, DeviceSIMReport
│
├── Services/
│   └── SIMDetectionService.swift     CoreTelephony detection (iOS 16/17/18 branching)
│
├── ViewModels/
│   └── SIMViewModel.swift            Published state, refresh logic
│
└── Views/
    ├── DesignSystem.swift             AppTheme tokens + ViewModifiers
    ├── ContentView.swift              Root scroll view
    ├── HeaderView.swift               App title + refresh button
    ├── UPIStatusBannerView.swift      Main SIM status card
    ├── SIMSlotDetailView.swift        Per-slot detail + StatusPill + DetailRow
    └── NetworkInfoView.swift          Network gen, carrier registry, detection info
```

---

## Indian Carrier MCC/MNC Reference (Info.plist)

All Indian carriers share **MCC 404**. The MNC differentiates each operator.

| Carrier | MCC | MNC |
|---|---|---|
| Reliance Jio | 404 | 88 |
| Bharti Airtel | 404 | 10 |
| Bharti Airtel (alt) | 404 | 20 |
| Vi / Vodafone | 404 | 05 |
| Vi / Idea | 404 | 24 |
| BSNL | 404 | 07 |
| BSNL (alt) | 404 | 04 |
| MTNL Delhi | 404 | 68 |
| MTNL Mumbai | 404 | 69 |
| Tata Teleservices | 404 | 71 |
| Tata Teleservices GSM | 404 | 72 |

> `isSIMInserted` returns `true` only if the inserted SIM's MCC+MNC matches one of the entries above.

---

## iOS Version Detection Strategy

| iOS | API Used | Reliable for SIM presence? |
|---|---|---|
| iOS 18+ | `CTSubscriberInfo().subscribers[n].isSIMInserted` | ✅ Yes — hardware level |
| iOS 16–17 | `serviceCurrentRadioAccessTechnology` | ⚠️ Signal required |
| iOS < 16 | `CTCarrier.mobileCountryCode` | ⚠️ Deprecated |

---

## Integration in UPI App Flow

```swift
// Pre-transaction security check
func initiatePayment(amount: Double) {
    guard SIMDetectionService.shared.isUPICapableSIMPresent() else {
        showError("Registered SIM not detected. Cannot authorise payment.")
        return
    }
    proceedWithPayment(amount: amount)
}
```

---

## Running

1. Open `UPISIMChecker.xcodeproj` in **Xcode 16**
2. Set your **Team** under Signing & Capabilities
3. Select a **physical iPhone** as the target (not Simulator)
4. Build & Run `⌘R`
5. Tap the refresh button `↺` to re-run detection

---

## Known Limitations

- `isSIMInserted` always returns `false` on Simulator — tested on physical device only
- `CTCarrier` MCC/MNC deprecated on iOS 16.4+ SDK — carrier name won't display on iOS 16+
- `isSIMInserted` checks against `CarrierDescriptors` — SIM from unlisted carrier returns `false`
