#!/usr/bin/env python3
"""
Run from project root: python3 generate_colors.py
Generates all color assets for UPISIMChecker dark-first design.
"""
import os, json

BASE = "UPISIMChecker/Assets.xcassets"

COLORS = {
    # Backgrounds (dark-first)
    "BG0":             {"dark": (0.035, 0.039, 0.055), "light": (0.949, 0.953, 0.965)},
    "BG1":             {"dark": (0.055, 0.063, 0.094), "light": (1.000, 1.000, 1.000)},
    "BG2":             {"dark": (0.031, 0.039, 0.063), "light": (0.941, 0.945, 0.957)},
    # Text
    "TextPrimary":     {"dark": (0.918, 0.925, 0.953), "light": (0.067, 0.071, 0.090)},
    "TextSecondary":   {"dark": (0.545, 0.573, 0.667), "light": (0.290, 0.306, 0.376)},
    "TextTertiary":    {"dark": (0.310, 0.337, 0.431), "light": (0.502, 0.518, 0.584)},
    # Borders
    "Border":          {"dark": (0.110, 0.125, 0.184), "light": (0.784, 0.792, 0.824)},
    "BorderSubtle":    {"dark": (0.078, 0.090, 0.137), "light": (0.863, 0.871, 0.898)},
    # Accents
    "AccentBlue":      {"dark": (0.290, 0.600, 1.000), "light": (0.094, 0.369, 0.820)},
    "AccentGreen":     {"dark": (0.235, 0.843, 0.549), "light": (0.059, 0.533, 0.271)},
    "AccentRed":       {"dark": (1.000, 0.400, 0.400), "light": (0.820, 0.141, 0.141)},
    "AccentAmber":     {"dark": (0.961, 0.737, 0.200), "light": (0.729, 0.475, 0.043)},
    "AccentPurple":    {"dark": (0.745, 0.612, 1.000), "light": (0.431, 0.251, 0.788)},
}

def make_colorset(name, dark, light):
    folder = os.path.join(BASE, f"{name}.colorset")
    os.makedirs(folder, exist_ok=True)
    r_d, g_d, b_d = dark
    r_l, g_l, b_l = light
    data = {
        "colors": [
            {
                "color": {"color-space": "srgb", "components": {
                    "alpha": "1.000", "red": f"{r_l:.3f}", "green": f"{g_l:.3f}", "blue": f"{b_l:.3f}"
                }},
                "idiom": "universal"
            },
            {
                "color": {"color-space": "srgb", "components": {
                    "alpha": "1.000", "red": f"{r_d:.3f}", "green": f"{g_d:.3f}", "blue": f"{b_d:.3f}"
                }},
                "idiom": "universal",
                "appearances": [{"appearance": "luminosity", "value": "dark"}]
            }
        ],
        "info": {"author": "xcode", "version": 1}
    }
    with open(os.path.join(folder, "Contents.json"), "w") as f:
        json.dump(data, f, indent=2)

if __name__ == "__main__":
    # Write root Contents.json
    with open(os.path.join(BASE, "Contents.json"), "w") as f:
        json.dump({"info": {"author": "xcode", "version": 1}}, f, indent=2)

    for name, vals in COLORS.items():
        make_colorset(name, vals["dark"], vals["light"])
        print(f"  ✓ {name}.colorset")

    print(f"\nDone — {len(COLORS)} color sets generated in {BASE}")
